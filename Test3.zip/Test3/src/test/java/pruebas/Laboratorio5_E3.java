package pruebas;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Laboratorio5_E3 {
	
	WebDriver driver;

	String driverPath="..\\Educacionit_Test3\\Drivers\\chromedriver.exe";
	String url="https://demoqa.com/alerts";
	
	@BeforeSuite
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",driverPath);
		driver= new ChromeDriver();	
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
	}
	
	
	   @AfterSuite
		public void finSuite() {
		  driver.close();
		}
		
		
		@Test()
		public void verAlert() {
			
	
            
			//WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(10));
			//wait.until(ExpectedConditions.elementToBeClickable(By.id("alertButton")));
			driver.findElement(By.id("alertButton")).click();
			
			Alert alert = driver.switchTo().alert();
			
			alert.accept();
		
		
	
		}


}
