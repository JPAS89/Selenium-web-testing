package pruebas;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import paginas.paginaLogin;

public class Laboratorio4_E1Extra {

	
	
	WebDriver driver;

	paginaLogin login;
	
	String driverPath="..\\Educacionit_Test3\\Drivers\\chromedriver.exe";
	String url="http://automationpractice.com/index.php?controller=authentication";
	
	
    @BeforeSuite
	public void setUp(){
     	System.setProperty("webdriver.chrome.driver",driverPath);
		driver= new ChromeDriver();	
		driver.get(url);
    	
      }
    
    @AfterSuite
  	public void cierreNavegador(){
       driver.close();
       }
    
   @Test
    public void irRegistroLogin() {
    	login= new paginaLogin(driver);
    	login.enterEmail("test1@gmail.com", "ABCD");
    	Assert.assertEquals(login.getTextTitleForm(), "AUTHENTICATION");
    	
     }
   
}


