package pruebas;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import paginas.paginaLogin_1;

public class Laboratorio5_E1 {

	
	
	WebDriver driver;

	paginaLogin_1 login;
	
	String driverPath="..\\Educacionit_Test3\\Drivers\\chromedriver.exe";
	String url="http://automationpractice.com/index.php?controller=authentication";
	
	
    @BeforeSuite
	public void setUp(){
     	System.setProperty("webdriver.chrome.driver",driverPath);
		driver= new ChromeDriver();	
		driver.get(url);
    	
      }
    
    @AfterSuite
  	public void cierreNavegador(){
       driver.close();
       }
    
   @Test(dataProvider="Datos Login")
    public void irRegistroLogin(String email,String password) {
    	login= new paginaLogin_1(driver);
    	//login.enterEmail("test1@gmail.com", "ABCD");
    	login.enterEmail(email,password);
    	Assert.assertEquals(login.getTextTitleForm(), "AUTHENTICATION");
    	
     }
   
    @DataProvider(name="Datos Login")
    public Object[][] getData(){
    	
	  Object[][] data= new Object[2][2]; 
	  
	   data[0][0]="test1@gmail.com"; data[0][1]="123";
	   data[1][0]="test2@gmail.com"; data[1][1]="456";
	   return data;
   }
    
    
}


