package pruebas;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class CrossBrowserTest {
	
	WebDriver driver;
    String url="http://automationpractice.com/index.php?controller=authentication";
    String driverPath="..\\Educacionit_Test3\\Drivers\\chromedriver.exe";
    String driverPathF="..\\Educacionit_Test3\\Drivers\\geckodriver.exe";
    
	@BeforeTest
	@Parameters("navegador")
	public void setUp(String navegador) throws Exception{
	
		if (navegador.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", driverPath);
			driver=new ChromeDriver();
		}
		else if (navegador.equalsIgnoreCase("Firefox"))
		{
		 	System.setProperty("webdriver.gecko.driver", driverPathF);
			driver=new FirefoxDriver();

		}
		else
          {
              //If no browser passed throw exception
              throw new Exception("Browser is not correct");
          }
		
		   driver.get(url);
		   driver.manage().window().maximize();
		   driver.manage().deleteAllCookies();
		   
		
		
	}
	
	@Test
	public void buscarPalabra() {
		 WebElement txtBuscador=driver.findElement(By.id("search_query_top"));
		   
		   txtBuscador.clear();
		   
		   txtBuscador.sendKeys("Blouse");
		   
		   txtBuscador.sendKeys(Keys.ENTER);
	
	}
	
	@AfterTest
	public void cierreNavegador() {
		
	  driver.close();
	
	}

}
