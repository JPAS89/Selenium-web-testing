package pruebas;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;


import paginas.paginaLogin_2;

public class Laboratorio4_E1Extra3 {
	WebDriver driver;
	paginaLogin_2 login;
	
	String driverPath="..\\Educacionit_Test3\\Drivers\\chromedriver.exe";
	String url="http://automationpractice.com/index.php?controller=authentication";
	
	  @BeforeSuite
		public void setUp(){
	     	System.setProperty("webdriver.chrome.driver",driverPath);
			driver= new ChromeDriver();	
			driver.get(url);
	    	
	      }
	    
	    @AfterSuite
	  	public void cierreNavegador(){
	       driver.close();
	       }
	    
	   @Test
	    public void irRegistroLogin() {
	    
		   login=new paginaLogin_2(driver);
		   login.enterEmail("test1@gmail.com","123");
	       Assert.assertEquals(login.getTextTitleForm(),"AUTHENTICATION");
	     }
	   
	

}
