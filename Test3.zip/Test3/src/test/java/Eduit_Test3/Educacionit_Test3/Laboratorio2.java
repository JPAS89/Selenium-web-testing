package Eduit_Test3.Educacionit_Test3;

import org.junit.*; 
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait; 
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;


public class Laboratorio2 {
	
	@Test
	public void lab2_E1() {
		
		  System.setProperty("webdriver.chrome.driver", "..\\Educacionit\\Drivers\\chromedriver.exe");
			
		   WebDriver driver=new ChromeDriver();
			
		   driver.get("http://automationpractice.com/index.php?controller=authentication#account-creation");
		   
		   WebElement txtEmail=driver.findElement(By.id("email_create"));
		   txtEmail.sendKeys("micorreo"+ Math.random()+"@correo.com");
		   
		   WebElement btnCreate=driver.findElement(By.xpath("//body[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/form[1]/div[1]/div[3]/button[1]/span[1]"));
		   
		   btnCreate.click();
		   
		   
		   WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		   wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(@id,'id_gender1')]")));
		  
		   driver.findElement(By.id("id_gender1"));
		
		 
			//c)
			driver.findElement(By.name("customer_firstname")).sendKeys("Juan Torres"); 
			
			//d)
			driver.findElement(By.name("passwd")).sendKeys("123456"); 
			
			//e)
			Select months= new Select(driver.findElement(By.name("months")));
			
			months.selectByValue("4");
			//h)
			driver.findElement(By.xpath("//*[text()='Register']")).click();
			
			driver.close();
			
	}

}
