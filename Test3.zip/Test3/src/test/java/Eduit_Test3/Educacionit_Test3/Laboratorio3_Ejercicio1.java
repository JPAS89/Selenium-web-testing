package Eduit_Test3.Educacionit_Test3;

import org.testng.Assert;
import org.testng.annotations.*;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;


public class Laboratorio3_Ejercicio1 {
	
	WebDriver driver;
    String url="http://automationpractice.com/index.php?controller=authentication";
    String driverPath="..\\Educacionit_Test3\\Drivers\\chromedriver.exe";
	@BeforeSuite
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", driverPath);
		driver=new ChromeDriver();
	}
	
	@BeforeTest
    public void irUrl() {
		driver.get(url);
		
	}
	
	@BeforeClass
	public void maxVentana() {
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
	}
	
	@Test(priority=2)
	public void registrarUsuario() {
		

		//a)
		WebElement txtEmail=driver.findElement(By.id("email_create"));
		txtEmail.sendKeys("micorreo"+Math.random()+"@correo.com");
		
		//b)
		WebElement btnCreate=driver.findElement(By.xpath("//button[@name='SubmitCreate']"));
		btnCreate.click();
		
		//Completar formulario
		
		//g)
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(@id,'id_gender1')]")));
		driver.findElement(By.id("id_gender1")).click();
		
		//c)
		driver.findElement(By.name("customer_firstname")).sendKeys("Juan Torres"); 
		
		//d)
		driver.findElement(By.name("passwd")).sendKeys("123456"); 
		
		//e)
		Select months= new Select(driver.findElement(By.name("months")));
		
		months.selectByValue("4");
		//h)
		driver.findElement(By.xpath("//*[text()='Register']")).click();
		
	     //Compara si dos objetos son iguales
		
		Assert.assertEquals(url, driver.getCurrentUrl());
		
		
		//valida un resultado si es verdadero
		Assert.assertTrue(url.equals(driver.getCurrentUrl()));
	
	}
	
	@Test(priority=1)
	public void pruebaTest() {
		assertTrue( true );
	}
	

	@AfterMethod
	public void capturaPantalla () throws Exception {
		File screen=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screen, new File("..\\Educacionit_Test3\\Evidencias\\pantalla.png"));
		
	  }
	
	@AfterClass
	public void finPrueba() {
		System.out.println("Fin de prueba");
	}
    @AfterTest
	public void cierraNavegador() {
	    driver.close();
	    }
    @AfterSuite
	public void finSuite () {
		System.out.println("Fin de Suite");
	}
	
	

}
