package Eduit_Test3.Educacionit_Test3;

import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;


public class Laboratorio1 {
	
	@Test @Ignore
	public void lab1_test() {
		
		System.out.println("¡Hola Mundo de Automatización!");
		
		
		
		
	}
	
	@Test @Ignore
	public void lab1_E1(){
	
	   System.setProperty("webdriver.chrome.driver", "..\\Educacionit_Test3\\Drivers\\chromedriver.exe");
	   
	   WebDriver driver= new ChromeDriver();
	   
	   driver.get("http://automationpractice.com/index.php");
	   
	   driver.manage().window().maximize();
	   
	   //driver.close();
	   
	   
	
	}
	
	@Test
	public void lab1_E3(){
	
	   System.setProperty("webdriver.chrome.driver", "..\\Educacionit_Test3\\Drivers\\chromedriver.exe");
	   
	   WebDriver driver= new ChromeDriver();
	   
	   driver.get("http://automationpractice.com/index.php");
	   
	   driver.manage().window().maximize();
	   
	   WebElement txtBuscador=driver.findElement(By.id("search_query_top"));
	   
	   txtBuscador.clear();
	   
	   txtBuscador.sendKeys("Blouse");
	   
	   txtBuscador.sendKeys(Keys.ENTER);
	   
	   driver.close();
	   

	
	}
    

	
	
}
