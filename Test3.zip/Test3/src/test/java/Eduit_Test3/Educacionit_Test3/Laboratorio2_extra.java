package Eduit_Test3.Educacionit_Test3;

import java.time.Duration;

import org.junit.*; 
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
public class Laboratorio2_extra {
	
   
	@Test
	public void lab2_E1Test() {
		  
		  String url="http://automationpractice.com/index.php?controller=authentication#account-creation";
		
		   System.setProperty("webdriver.chrome.driver", "..\\Educacionit_Test3\\Drivers\\chromedriver.exe");
		   
		   WebDriver driver= new ChromeDriver();
		   
		   driver.get(url);
		   
		   driver.manage().window().maximize();
		   
		   
		   WebElement txtEmail=driver.findElement(By.id("email_create"));
		   txtEmail.sendKeys("micorreo"+ Math.random()+"@correo.com");
		   
		   
		   WebElement btnCreate=driver.findElement(By.xpath("//*[@id='SubmitCreate']"));
		   
		   
		   btnCreate.click();
		   
		   //g)
		   WebDriverWait mywait=new WebDriverWait(driver,Duration.ofSeconds(10));
		   mywait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(@id,'id_gender1')]")));
		   
		   driver.findElement(By.id("id_gender1")).click();
		   
			//c)
			driver.findElement(By.name("customer_firstname")).sendKeys("Juan Torres"); 
			
			//d)
			driver.findElement(By.name("passwd")).sendKeys("123456"); 
			
			//e)
			
			Select months= new Select(driver.findElement(By.id("months")));
			
			months.selectByValue("4");
			//h)
			driver.findElement(By.xpath("//*[text()='Register']")).click();
			
			driver.close();
			
		   

		   
		
	
	}
	
	

}
